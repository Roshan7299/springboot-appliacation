package com.example.my_springboot_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringbootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
